$("#commentForm").bootstrapValidator({
    fields: {
        name: {
            validators: {
                notEmpty: {
                    message: 'The Category name is required'
                }
            },
            required: true,
            minlength: 3
        }
    }
});