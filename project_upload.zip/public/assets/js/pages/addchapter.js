$("#commentForm").bootstrapValidator({
    fields: {
        name: {
            validators: {
                notEmpty: {
                    message: 'The Chapter name is required'
                }
            },
            required: true,
            minlength: 3
        },
        courses_id: {
            validators: {
                notEmpty: {
                    message: 'The Course is required'
                }
            }
        }
    }
});

