$("#commentForm").bootstrapValidator({
    fields: {
        name: {
            validators: {
                notEmpty: {
                    message: 'The Course name is required'
                }
            },
            required: true,
            minlength: 3
        },
        price: {
            validators: {
                notEmpty: {
                    message: 'The Course price is required'
                }
            },
            required: true
        },
        public: {
            validators: {
                notEmpty: {
                    message: 'Is course private or public is required'
                }
            }
        },
        category_id: {
            validators: {
                notEmpty: {
                    message: 'The Category is required'
                }
            }
        },
        free_content_limit: {
            validators: {
                notEmpty: {
                    message: 'The Free Content Limit is required'
                }
            }
        }
    }
});

