$("#commentForm").bootstrapValidator({
    fields: {
        courses_id: {
            validators: {
                notEmpty: {
                    message: 'The Course is required'
                }
            }
        },
        chapter_id: {
            validators: {
                notEmpty: {
                    message: 'The Chapter is required'
                }
            }
        },
        name: {
            validators: {
                notEmpty: {
                    message: 'The name is required'
                }
            }
        }
    }
});