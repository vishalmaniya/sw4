$("table").DataTable({
    responsive:true
});