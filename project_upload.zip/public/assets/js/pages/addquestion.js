$("#commentForm").bootstrapValidator({
    fields: {
        lession_id: {
            validators: {
                notEmpty: {
                    message: 'The Lession is required'
                }
            }
        },
        type: {
            validators: {
                notEmpty: {
                    message: 'The Type is required'
                }
            }
        },
        question: {
            validators: {
                notEmpty: {
                    message: 'The Question is required'
                }
            }
        },
        description: {
            validators: {
                notEmpty: {
                    message: 'The Description is required'
                }
            }
        },
        language: {
            validators: {
                notEmpty: {
                    message: 'The Language is required'
                }
            }
        },
        answer_type: {
            validators: {
                notEmpty: {
                    message: 'The Answer Type is required'
                }
            }
        },
        answer: {
            validators: {
                notEmpty: {
                    message: 'The Answer is required'
                }
            }
        },
        answer_text: {
            validators: {
                notEmpty: {
                    message: 'The Answer is required'
                }
            }
        },
        option1: {
            validators: {
                notEmpty: {
                    message: 'The Option 1 is required'
                }
            }
        },
        option2: {
            validators: {
                notEmpty: {
                    message: 'The Option 2 is required'
                }
            }
        },
        option3: {
            validators: {
                notEmpty: {
                    message: 'The Option 3 is required'
                }
            }
        },
        option4: {
            validators: {
                notEmpty: {
                    message: 'The Option 4 is required'
                }
            }
        },
        option5: {
            validators: {
                notEmpty: {
                    message: 'The Option 5 is required'
                }
            }
        },
        default: {
            validators: {
                notEmpty: {
                    message: 'The Default value is required'
                }
            }
        },
        points_correct: {
            validators: {
                notEmpty: {
                    message: 'The Correct Point is required'
                }
            }
        },
        points_incorrect: {
            validators: {
                notEmpty: {
                    message: 'The Correct Point is required'
                }
            }
        },
        hint_points: {
            validators: {
                notEmpty: {
                    message: 'The Hint Point is required'
                }
            }
        },
        hint1: {
            validators: {
                notEmpty: {
                    message: 'The Hint 1 is required'
                }
            }
        },
        hint2: {
            validators: {
                notEmpty: {
                    message: 'The Hint 2 is required'
                }
            }
        },
        hint3: {
            validators: {
                notEmpty: {
                    message: 'The Hint 3 is required'
                }
            }
        }
    }
});
CKEDITOR.on('instanceCreated', function(event) {
    var editor = event.editor,
        element = editor.element;
    if (element.is('h1', 'h2', 'h3') || element.getAttribute('id') == 'taglist') {
        editor.on('configLoaded', function() {
            editor.config.removePlugins = 'colorbutton,find,flash,font,' +
                'forms,iframe,image,newpage,removeformat,' +
                'smiley,specialchar,stylescombo,templates';
            editor.config.toolbarGroups = [{
                name: 'editing',
                groups: ['basicstyles', 'links']
            }, {
                name: 'undo'
            }, {
                name: 'clipboard',
                groups: ['selection', 'clipboard']
            }, {
                name: 'about'
            }];
        });
    }
});

$('.form-group').hide();
var val_que = $("#type").val();
$('.'+val_que).show();
if(val_que == 'chapter_review'){
    var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
        bootstrapValidator.enableFieldValidators('option1', false);
        bootstrapValidator.enableFieldValidators('option2', false);
        bootstrapValidator.enableFieldValidators('option3', false);
        bootstrapValidator.enableFieldValidators('option4', false);
        bootstrapValidator.enableFieldValidators('option5', false);
        bootstrapValidator.enableFieldValidators('answer', false);
        bootstrapValidator.enableFieldValidators('answer_text', true);
        bootstrapValidator.enableFieldValidators('language', true);
        bootstrapValidator.enableFieldValidators('answer_type', true);
        bootstrapValidator.enableFieldValidators('default', true);
}else if(val_que == 'multichoise'){
    var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
        bootstrapValidator.enableFieldValidators('option1', true);
        bootstrapValidator.enableFieldValidators('option2', true);
        bootstrapValidator.enableFieldValidators('option3', true);
        bootstrapValidator.enableFieldValidators('option4', true);
        bootstrapValidator.enableFieldValidators('option5', true);
        bootstrapValidator.enableFieldValidators('answer', true);
        bootstrapValidator.enableFieldValidators('answer_text', false);
        bootstrapValidator.enableFieldValidators('language', false);
        bootstrapValidator.enableFieldValidators('answer_type', false);
        bootstrapValidator.enableFieldValidators('default', false);
}else if(val_que == 'textarea'){
    var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
        bootstrapValidator.enableFieldValidators('option1', false);
        bootstrapValidator.enableFieldValidators('option2', false);
        bootstrapValidator.enableFieldValidators('option3', false);
        bootstrapValidator.enableFieldValidators('option4', false);
        bootstrapValidator.enableFieldValidators('option5', false);
        bootstrapValidator.enableFieldValidators('answer', false);
        bootstrapValidator.enableFieldValidators('answer_text', true);
        bootstrapValidator.enableFieldValidators('language', true);
        bootstrapValidator.enableFieldValidators('answer_type', true);
        bootstrapValidator.enableFieldValidators('default', true);
}

function change_quetion(val){
    $('.form-group').hide();
    $('.'+val).show();
    if(val == 'chapter_review'){
        var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
            bootstrapValidator.enableFieldValidators('option1', false);
            bootstrapValidator.enableFieldValidators('option2', false);
            bootstrapValidator.enableFieldValidators('option3', false);
            bootstrapValidator.enableFieldValidators('option4', false);
            bootstrapValidator.enableFieldValidators('option5', false);
            bootstrapValidator.enableFieldValidators('answer', false);
            bootstrapValidator.enableFieldValidators('answer_text', true);
            bootstrapValidator.enableFieldValidators('language', true);
            bootstrapValidator.enableFieldValidators('answer_type', true);
            bootstrapValidator.enableFieldValidators('default', true);
    }else if(val == 'multichoise'){
        var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
            bootstrapValidator.enableFieldValidators('option1', true);
            bootstrapValidator.enableFieldValidators('option2', true);
            bootstrapValidator.enableFieldValidators('option3', true);
            bootstrapValidator.enableFieldValidators('option4', true);
            bootstrapValidator.enableFieldValidators('option5', true);
            bootstrapValidator.enableFieldValidators('answer', true);
            bootstrapValidator.enableFieldValidators('answer_text', false);
            bootstrapValidator.enableFieldValidators('language', false);
            bootstrapValidator.enableFieldValidators('answer_type', false);
            bootstrapValidator.enableFieldValidators('default', false);
    }else if(val == 'textarea'){
        var bootstrapValidator = $('#commentForm').data('bootstrapValidator');
            bootstrapValidator.enableFieldValidators('option1', false);
            bootstrapValidator.enableFieldValidators('option2', false);
            bootstrapValidator.enableFieldValidators('option3', false);
            bootstrapValidator.enableFieldValidators('option4', false);
            bootstrapValidator.enableFieldValidators('option5', false);
            bootstrapValidator.enableFieldValidators('answer', false);
            bootstrapValidator.enableFieldValidators('answer_text', true);
            bootstrapValidator.enableFieldValidators('language', true);
            bootstrapValidator.enableFieldValidators('answer_type', true);
            bootstrapValidator.enableFieldValidators('default', true);
    }
}
// CKEditor Full
$('textarea#question').ckeditor({
    height: '200px'
});
$('textarea#answer_text').ckeditor({
    height: '200px'
});
$('textarea#default').ckeditor({
    height: '200px'
});
$('textarea#description').ckeditor({
    height: '200px'
});