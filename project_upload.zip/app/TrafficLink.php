<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrafficLink extends Model
{
    protected $table = 'traffic_link';
    public $primaryKey = 'id';
}
